function [frequences_triees,indices_frequences_triees] = tri(selection_frequences)
[frequences_triees,indices_frequences_triees]=sort(selection_frequences, 'descend')
