function coeff_compression = coeff_compression_texte(texte,texte_encode)
coeff_compression=length(texte)*8/length(texte_encode)

