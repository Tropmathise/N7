clear variables
close all

% chargement du jeu de donn�es
load('dataset.mat')
