#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <limits.h>
#include <fcntl.h>
#include "readcmd.h"
#include "readcmd.c"
#include "processus.h"
#include "processus.c"

ListeProcessus *Liste;

void suivi_fils (int sig){ /* Récupère SIG_CHLD */
	int etat_fils, pid_fils;
	do {
		pid_fils = waitpid(-1, &etat_fils, WNOHANG | WUNTRACED | WCONTINUED);
		if ((pid_fils == -1) && (errno != ECHILD )) {
			perror("waitpid");
			exit(EXIT_FAILURE);
		} else if (pid_fils > 0) {
			if (WIFSTOPPED(etat_fils)) {
				/* Changer l'état du processus dans la liste */
				changerEtat(Liste,pid_fils,false);
				perror("Erreur du stop");
			} else if (WIFCONTINUED(etat_fils)) {
				/* Changer l'état du processus dans la liste */
				changerEtat(Liste,pid_fils,true);
				perror("Erreur du continue");
			} else if (WIFEXITED(etat_fils)) {
				/* Retirer le processus de la liste des processus actifs */
				/*supprimer(Liste,pid_fils);*/
				perror("Erreur de l'exit");
			} else if (WIFSIGNALED(etat_fils)) {
				/* Retirer le processus de la liste des processus actifs */
				/*supprimer(Liste,pid_fils);*/
				perror("Erreur du signaled");
			}
		}
	} while (pid_fils > 0);
}

void stop(int signal){
	/* Chercher s'il y a un processus en avant plan dans la liste des processus et, si c'est le cas, lui envoyer le signal SIGSTOP */
	int pid = getPID_avant_plan(Liste);
	kill(pid,SIGSTOP);
}

void tuer(int signal){
	/* Chercher s'il y a un processus en avant plan dans la liste des processus et, si c'est le cas, lui envoyer le signal SIGKILL */
	int pid = getPID_avant_plan(Liste);
	kill(pid,SIGKILL);
}

int main(int argc, char **argv)
{
	Liste = initialisation();
	struct cmdline *Commande;
	int pid, cd;
	struct sigaction ctrl_z;
	struct sigaction ctrl_c;
	struct sigaction gestion_liste;
	ctrl_z.sa_handler = &stop;
	ctrl_c.sa_handler = &tuer;
	gestion_liste.sa_handler = &suivi_fils;
	sigaction(SIGTSTP, &ctrl_z, NULL);
	sigaction(SIGINT, &ctrl_c, NULL);
	sigaction(SIGCHLD, &gestion_liste, NULL);
	sigset_t set;
	sigemptyset(&set);
	sigaddset(&set, SIGINT);
	sigaddset(&set, SIGTSTP);
	while (true) {
		Commande = readcmd();
		if (Commande != NULL) {
			if ((strcmp(Commande -> seq[0][0], "cd") == 0)){
				cd = chdir(Commande -> seq[0][1]);
				if (cd == -1){
					perror("Erreur lors de l'exécution du père");
				}
			} else if ((strcmp(Commande -> seq[0][0], "exit") == 0)) {
				exit(EXIT_SUCCESS);
			} else if ((strcmp(Commande -> seq[0][0], "jobs") == 0)) {
				/*Afficher les informations relatives aux processus actifs */
				afficher(Liste);
			} else if ((strcmp(Commande -> seq[0][0], "stop") == 0)) {
				kill(atoi(Commande -> seq[0][1]), SIGSTOP);
			} else if ((strcmp(Commande -> seq[0][0], "bg") == 0)) {
				kill(atoi(Commande -> seq[0][1]), SIGCONT);
			} else if ((strcmp(Commande -> seq[0][0], "fg") == 0)) {
				kill(atoi(Commande -> seq[0][1]), SIGCONT);
				pause();
			} else {
				pid = fork();
				/* Ajouter le processus dans la liste */
				insertion(Liste, pid, Commande -> seq[0][0], true, (Commande -> backgrounded == NULL));
				if (pid == 0){
					sigprocmask(SIG_BLOCK, &set, NULL);
					if (Commande -> in != NULL) {
						int descripteur_entree = open(Commande -> in, O_RDONLY);
						perror("Erreur dans le fichier entrée");
						printf(Commande -> in);
						dup2(descripteur_entree, 0);
						close(descripteur_entree);
					}
					if (Commande -> out != NULL) {
						int descripteur_sortie = open(Commande -> out, O_CREAT | O_WRONLY | O_TRUNC);
						perror("Erreur dans le fichier sortie");
						printf(Commande -> out);
						dup2(descripteur_sortie, 1);
						close(descripteur_sortie);
					}
					if (Commande -> seq[1] == NULL){
						execvp(Commande -> seq[0][0] , *(Commande -> seq));
						exit(EXIT_SUCCESS);
						perror("Erreur lors de l'exécution du fils (une commande): ");
					} else {
						int p[2];
						pipe(p);
						int pid_fils = fork();
						if (pid_fils == 0) {
							close(p[0]);
							dup2(p[1], 1);
							execvp(Commande -> seq[0][0] , *(Commande -> seq));
							exit(EXIT_SUCCESS);
							perror("Erreur lors de l'exécution du petit-fils: ");
						} else {
							close(p[1]);
							dup2(p[0], 0);
							execvp(Commande -> seq[1][0] , Commande -> seq[1]);
							exit(EXIT_SUCCESS);
							perror("Erreur lors de l'exécution du fils: ");
						}
					}
						
				}
				else {
					printf("Processus père\n");
					if ((Commande -> backgrounded) == NULL){
						pause();
					}
				}
			}
		}
	}
	return 0;
}
