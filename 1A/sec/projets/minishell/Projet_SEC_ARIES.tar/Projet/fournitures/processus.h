#ifndef PROCESSUS
#define	PROCESSUS
#include <stdbool.h>

typedef struct Processus *ListeProcessus;

ListeProcessus initialisation();
void insertion(ListeProcessus *LP, int pid, char *cmd, bool etat, bool avant_plan);
void supprimer(ListeProcessus *LP, int PID);
void afficher(ListeProcessus *LP);
void changerEtat(ListeProcessus *LP, int PID, bool ETAT);
void changerPlan(ListeProcessus *LP, int PID, bool PLAN);
int getPID_avant_plan(ListeProcessus *LP);

#endif
