#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include "processus.h"

struct Processus
{
	int pid;
	bool actif;
	bool avant_plan;
	char *cmd;
	struct Processus *suivant;
	/* L'identifiant du minishell sera égal au PID*/
};
typedef struct Processus Processus;

ListeProcessus initialisation(){
	ListeProcessus *LP = (ListeProcessus*) malloc(sizeof(*LP));
	Processus *P = malloc(sizeof(*P));
	
	if (LP == NULL || P == NULL){
		perror("Erreur lors de l'initialisation");
	}
	
	P -> pid = -1;
	P -> actif = false;
	P -> avant_plan = false;
	P -> cmd = NULL;
	P -> suivant = NULL;
	*LP = P;
	return *LP;
}

void insertion(ListeProcessus *LP, int pid, char *cmd, bool etat, bool avant_plan){
	Processus *nouveau = malloc(sizeof(*nouveau));
	
	if (LP == NULL || nouveau == NULL){
		perror("Erreur lors de l'insertion");
	}
	
	nouveau -> pid = pid;
	nouveau -> actif = etat;
	nouveau -> avant_plan = avant_plan;
	nouveau -> cmd = cmd;
	nouveau -> suivant = *LP;
	*LP = nouveau;
	
}

void supprimer(ListeProcessus *LP, int PID){
	ListeProcessus parcours = *LP;
	
	printf("%d",parcours -> pid);
	
	while ((parcours -> suivant != NULL) && (parcours -> pid != PID)){
		parcours = parcours -> suivant;
	}
	if (parcours -> pid != PID){
		printf("Le PID : %d, n'est pas présent dans la liste des processus actifs\n", PID);
	} else {
		parcours -> suivant = parcours -> suivant -> suivant;
	}
}

void afficher(ListeProcessus *LP){
	ListeProcessus parcours = *LP;
	int identifiant = 1;
	if (LP == NULL){
		printf("La liste n'a pas encore été initialisée\n");
	} else {
		while (parcours != NULL){
			printf("Identifiant: %d		", parcours -> pid);
			printf("PID: %d		", parcours -> pid);
			if (parcours -> actif){
				printf("Etat: ACTIF		");
			} else {
				printf("Etat: SUSPENDU		");
			}
			printf(parcours -> cmd);
			printf("\n");
			parcours = parcours -> suivant;
			identifiant = identifiant + 1;
		}
	}
}

void changerEtat(ListeProcessus *LP, int PID, bool ETAT){
	ListeProcessus parcours = *LP;
	
	if (LP == NULL){
		printf("La liste n'a pas encore été initialisée\n");
	}
	while (parcours -> suivant != NULL && parcours -> pid != PID){ /*MODIFIER parcours -> suivant par parcours et du coup faut modifier les conditions juste en dessous ! :)*/
		parcours = parcours -> suivant;
	}
	if (parcours -> pid == PID){
		parcours -> actif = ETAT;
	} else {
		printf("Le PID: %d n'est pas présent dans la liste\n", PID);
	}
}

void changerPlan(ListeProcessus *LP, int PID, bool PLAN){
	ListeProcessus parcours = *LP;
	
	if (LP == NULL){
		printf("La liste n'a pas encore été initialisée\n");
	}
	while (parcours -> suivant != NULL && parcours -> pid != PID){ /*MODIFIER parcours -> suivant par parcours et du coup faut modifier les conditions juste en dessous ! :)*/
		parcours = parcours -> suivant;
	}
	if (parcours -> pid == PID){
		parcours -> avant_plan = PLAN;
	} else {
		printf("Le PID: %d n'est pas présent dans la liste\n", PID);
	}
}

int getPID_avant_plan(ListeProcessus *LP){
	ListeProcessus parcours = *LP;
	
	if (LP == NULL){
		printf("La liste n'a pas encore été initialisée\n");
	}
	while (parcours -> suivant != NULL && parcours -> avant_plan != true){ /*MODIFIER parcours -> suivant par parcours et du coup faut modifier les conditions juste en dessous ! :)*/
		parcours = parcours -> suivant;
	}
	if (parcours -> avant_plan == true){
		return parcours -> pid;
	} else {
		printf("Il n'y a pas de processus en avant-plan\n");
		return -1;
	}
}
