@doc doc"""
Minimise le problème : ``min_{||s||< \delta_{k}} q_k(s) = s^{t}g + (1/2)s^{t}Hs``
                        pour la ``k^{ème}`` itération de l'algorithme des régions de confiance

# Syntaxe
```julia
sk = Gradient_Conjugue_Tronque(fk,gradfk,hessfk,option)
```

# Entrées :   
   * **gradfk**           : (Array{Float,1}) le gradient de la fonction f appliqué au point xk
   * **hessfk**           : (Array{Float,2}) la Hessienne de la fonction f appliqué au point xk
   * **options**          : (Array{Float,1})
      - **delta**    : le rayon de la région de confiance
      - **max_iter** : le nombre maximal d'iterations
      - **tol**      : la tolérance pour la condition d'arrêt sur le gradient


# Sorties:
   * **s** : (Array{Float,1}) le pas s qui approche la solution du problème : ``min_{||s||< \delta_{k}} q(s)``

# Exemple d'appel:
```julia
gradf(x)=[-400*x[1]*(x[2]-x[1]^2)-2*(1-x[1]) ; 200*(x[2]-x[1]^2)]
hessf(x)=[-400*(x[2]-3*x[1]^2)+2  -400*x[1];-400*x[1]  200]
xk = [1; 0]
options = []
s = Gradient_Conjugue_Tronque(gradf(xk),hessf(xk),options)
```
"""
function Gradient_Conjugue_Tronque(gradfk,hessfk,options)

    "# Si option est vide on initialise les 3 paramètres par défaut"
    if options == []
        deltak = 2
        #max_iter=1
        max_iter = length(gradfk)*2
        tol = 1e-6
    else
        deltak = options[1]
        max_iter = options[2]
        tol = options[3]
    end

    n=length(gradfk)
    if n==1 
        sj=0
        s=0
    else 
        sj=zeros(n)
        s=zeros(n)
    end
    gj=gradfk
    pj=-gradfk
    H=hessfk
    nb_iters=0

    conv=-1

    while (conv==-1)
        kappaj = (pj')*H*(pj)

        if kappaj <= 0 

            #resolution du polynome
            a=norm(pj)^2
            b=2*(sj')*pj
            c=norm(sj)^2 - deltak^2
            determinant=b^2-4*a*c
            racine_determinant=sqrt(determinant)

            #racine du polynome
            sigmaj1=(-b-racine_determinant)/(2*a)
            sigmaj2=(-b+racine_determinant)/(2*a)

            #calcul de q(sj+sigmaj*pj)
            qsigmaj1=(gj')*(sj+sigmaj1*pj)+0.5*((sj+sigmaj1*pj)')*H*(sj+sigmaj1*pj)
            qsigmaj2=(gj')*(sj+sigmaj2*pj)+0.5*((sj+sigmaj2*pj)')*H*(sj+sigmaj2*pj)           

            if qsigmaj1<qsigmaj2
                sig = sigmaj1
            else 
                sig = sigmaj2
            end
            s=sj+sig*pj
            conv=0

            #pour interprétation
            #s=sj
        end

        #alphaj = gj'*gj/kappaj
        alphaj=norm(gj)^2/kappaj
        if norm(sj + alphaj*pj)>=deltak

            a=norm(pj)^2
            b=2*(sj')*pj
            c=norm(sj)^2 - deltak^2
            determinant=b^2-4*a*c
            racine_determinant=sqrt(determinant)

            #racine du polynome
            sigmaj1=(-b-racine_determinant)/(2*a)
            sigmaj2=(-b+racine_determinant)/(2*a)

            if sigmaj1>=0 
                sigmaj=sigmaj1
            elseif sigmaj2>=0
                sigmaj=sigmaj2
            else 
                sigmaj=-norm(sj)+deltak/norm(pj)
            end 
            s=sj+sigmaj*pj
            conv=0

            #pour interprétation
            #s=sj
        end

        #modification des parametres
        sj=sj+alphaj*pj
        gjp1=gj+alphaj*H*pj
        #betaj=(gjp1')*gjp1/((gj')*gj)
        betaj=(norm(gjp1)/norm(gj))^2
        pj=-gjp1+betaj*pj
        gj=gjp1
        
        #verification convergence
        if norm(gj)<tol*norm(gradfk)
            s=sj
            conv=0
        end
        if nb_iters==max_iter
            conv = 0
        end
        nb_iters=nb_iters+1
    end 

   return s
end
