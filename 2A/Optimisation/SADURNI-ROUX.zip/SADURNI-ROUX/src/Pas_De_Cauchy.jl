@doc doc"""
Approximation de la solution du sous-problème ``q_k(s) = s^{t}g + (1/2)s^{t}Hs`` 
        avec ``s=-t g_k,t > 0,||s||< \delta_k ``


# Syntaxe
```julia
s1, e1 = Pas_De_Cauchy(gradient,Hessienne,delta)
```

# Entrées
 * **gradfk** : (Array{Float,1}) le gradient de la fonction f appliqué au point ``x_k``
 * **hessfk** : (Array{Float,2}) la Hessienne de la fonction f appliqué au point ``x_k``
 * **delta**  : (Float) le rayon de la région de confiance

# Sorties
 * **s** : (Array{Float,1}) une approximation de la  solution du sous-problème
 * **e** : (Integer) indice indiquant l'état de sortie:
        si g != 0
            si on ne sature pas la boule
              e <- 1
            sinon
              e <- -1
        sinon
            e <- 0

# Exemple d'appel
```julia
g1 = [0; 0]
H1 = [7 0 ; 0 2]
delta1 = 1
s1, e1 = Pas_De_Cauchy(g1,H1,delta1)
```
"""
function Pas_De_Cauchy(g,H,delta)
  e = 0
  a=g'*H*g
  b=-norm(g)^2
  t_barre=-b/a
  eps = 1e-14
  if norm(g)>eps
    if a <=0 
      t=delta/norm(g)
    elseif a>0 && t_barre<=delta/norm(g)
      t=t_barre
    else
      t=delta/norm(g)
    end
  else 
    t=0
  end

  s=-t*g

  if norm(g) > eps
    if norm(s)>delta
      e=1
    else
      e=-1
    end
  else 
    e=0
  end

  return s, e

end
