#using Pkg; Pkg.add("LinearAlgebra"); Pkg.add("Markdown")
# using Documenter
using LinearAlgebra
using Markdown                             # Pour que les docstrings en début des fonctions ne posent
                                           # pas de soucis. Ces docstrings sont utiles pour générer 
                                           # la documentation sous GitHub
include("Algorithme_De_Newton.jl")

# Affichage les sorties de l'algorithme des Régions de confiance
function my_afficher_resultats_newton(algo,nom_fct,point_init,xmin,fxmin,flag,sol_exacte,nbiters)
	println("-------------------------------------------------------------------------")
	printstyled("Résultats de : ",algo, " appliqué à ",nom_fct, " au point initial ", point_init, ":\n",bold=true,color=:blue)
	println("  * xsol = ",xmin)
	println("  * f(xsol) = ",fxmin)
	println("  * nb_iters = ",nbiters)
	println("  * flag = ",flag)
	println("  * sol_exacte : ", sol_exacte)
end

# Fonction f0
# -----------
f0(x) =  sin(x)
# la gradient de la fonction f0
grad_f0(x) = cos(x)
# la hessienne de la fonction f0
hess_f0(x) = -sin(x)
sol_exacte = -pi/2
options = []

x0 = sol_exacte
xmin,f_min,flag,nb_iters = Algorithme_De_Newton(f0,grad_f0,hess_f0,x0,options)
my_afficher_resultats_newton("Newton","f0",x0,xmin,f_min,flag,sol_exacte,nb_iters)
x0 = -pi/2+0.5
xmin,f_min,flag,nb_iters = Algorithme_De_Newton(f0,grad_f0,hess_f0,x0,options)
my_afficher_resultats_newton("Newton","f0",x0,xmin,f_min,flag,sol_exacte,nb_iters)
x0 = pi/2
xmin,f_min,flag,nb_iters = Algorithme_De_Newton(f0,grad_f0,hess_f0,x0,options)
my_afficher_resultats_newton("Newton","f0",x0,xmin,f_min,flag,sol_exacte,nb_iters)

# Fonction f1
# -----------
f1(x) =  2(x[1]+x[2]+x[3]-3)^2 + (x[1]-x[2])^2 + (x[2]-x[3])^2

# le gradient de la fonction f1
grad_f1(x) = [6*x[1]+2*x[2]+4*x[3]-12,2*x[1]+8*x[2]+2*x[3]-12,4*x[1]+2*x[2]+6*x[3]-12]

# la hessienne de la fonction f1
hess_f1(x) = [6 2 4;2 8 2;4 2 6]
sol_exacte = [1,1,1]
options = []

x01 = sol_exacte
xmin,f_min,flag,nb_iters = Algorithme_De_Newton(f1,grad_f1,hess_f1,x01,options)
my_afficher_resultats_newton("Newton","f1",x01,xmin,f_min,flag,sol_exacte,nb_iters)
x011 = [1,0,0]
xmin,f_min,flag,nb_iters = Algorithme_De_Newton(f1,grad_f1,hess_f1,x011,options)
my_afficher_resultats_newton("Newton","f1",x011,xmin,f_min,flag,sol_exacte,nb_iters)
x012 = [10,3,-2.2]
xmin,f_min,flag,nb_iters = Algorithme_De_Newton(f1,grad_f1,hess_f1,x012,options)
my_afficher_resultats_newton("Newton","f1",x012,xmin,f_min,flag,sol_exacte,nb_iters)

# Fonction f2
# -----------
f2(x)=100*(x[2]-x[1]^2)^2+(1-x[1])^2

#le gradient de la fonction f2
grad_f2(x)=[-400*(x[1])*(x[2]-x[1]^2)-2*(1-x[1]), 200*(x[2]-x[1]^2)]

#la hessienne de la fonction f2
hess_f2(x)=[-400*((x[2]-x[1]^2)-2*x[1]^2)+2 -400*x[1]; -400*x[1] 200]
sol_exacte = [1,1]
options = []

x01 = sol_exacte
xmin,f_min,flag,nb_iters = Algorithme_De_Newton(f2,grad_f2,hess_f2,x01,options)
my_afficher_resultats_newton("Newton","f2",x01,xmin,f_min,flag,sol_exacte,nb_iters)
x021 = [-1.2,1]
xmin,f_min,flag,nb_iters = Algorithme_De_Newton(f2,grad_f2,hess_f2,x021,options)
my_afficher_resultats_newton("Newton","f2",x021,xmin,f_min,flag,sol_exacte,nb_iters)
x022 = [10,0]
xmin,f_min,flag,nb_iters = Algorithme_De_Newton(f2,grad_f2,hess_f2,x022,options)
my_afficher_resultats_newton("Newton","f2",x022,xmin,f_min,flag,sol_exacte,nb_iters)
x023 = [0,(1/200)+(1/10^(12))]
xmin,f_min,flag,nb_iters = Algorithme_De_Newton(f2,grad_f2,hess_f2,x023,options)
my_afficher_resultats_newton("Newton","f2",x023,xmin,f_min,flag,sol_exacte,nb_iters)


#using Pkg; Pkg.add("LinearAlgebra"); Pkg.add("Markdown")
# using Documenter
using LinearAlgebra
using Markdown                             # Pour que les docstrings en début des fonctions ne posent
                                           # pas de soucis. Ces docstrings sont utiles pour générer 
                                           # la documentation sous GitHub
include("Pas_De_Cauchy.jl")
include("Regions_De_Confiance.jl")

function my_afficher_resultats(algo,g,H,delta,s,e)
	println("-------------------------------------------------------------------------")
	printstyled("Résultats de : ",algo, " appliqué à g=",g," et H=", H," avec delta=",delta, bold=true,color=:blue)
    println(" ")
	println("  * s = ",s)
	println("  * e = ",e)
end

#quadratique 1
g1=[0;0]
H1=[7 0; 0 2]
delta1=1
s1,e1=Pas_De_Cauchy(g1,H1,delta1)
my_afficher_resultats("Pas de Cauchy",g1,H1,delta1,s1,e1)

#quadratique 2
g2=[6;2]
H2=[7 0; 0 2]
delta2=1
s2,e2=Pas_De_Cauchy(g2,H2,delta2)
my_afficher_resultats("Pas de Cauchy",g2,H2,delta2,s2,e2)

#quadratique 3
g3=[-2;1]
H3=[-2 0; 0 10]
delta3=1
s3,e3=Pas_De_Cauchy(g3,H3,delta3)
my_afficher_resultats("Pas de Cauchy",g3,H3,delta3,s3,e3)

println("-------------------------------------------------------------------------------")
println("-------------------------------------------------------------------------------")

sol_exacte = -pi/2
options = []
x0 = sol_exacte
xmin,f_min,flag,nb_iters = Regions_De_Confiance("cauchy",f0,grad_f0,hess_f0,x0,options)
my_afficher_resultats_newton("RDC","f0",x0,xmin,f_min,flag,sol_exacte,nb_iters)
x0 = -pi/2+0.5
xmin,f_min,flag,nb_iters = Regions_De_Confiance("cauchy",f0,grad_f0,hess_f0,x0,options)
my_afficher_resultats_newton("RDC","f0",x0,xmin,f_min,flag,sol_exacte,nb_iters)
x0 = pi/2
xmin,f_min,flag,nb_iters = Regions_De_Confiance("cauchy",f0,grad_f0,hess_f0,x0,options)
my_afficher_resultats_newton("RDC","f0",x0,xmin,f_min,flag,sol_exacte,nb_iters)

sol_exacte = [1,1,1]
options = []
x01 = sol_exacte
xmin,f_min,flag,nb_iters = Regions_De_Confiance("cauchy",f1,grad_f1,hess_f1,x01,options)
my_afficher_resultats_newton("RDC","f1",x01,xmin,f_min,flag,sol_exacte,nb_iters)
x011 = [1,0,0]
xmin,f_min,flag,nb_iters = Regions_De_Confiance("cauchy",f1,grad_f1,hess_f1,x011,options)
my_afficher_resultats_newton("RDC","f1",x011,xmin,f_min,flag,sol_exacte,nb_iters)
x012 = [10,3,-2.2]
xmin,f_min,flag,nb_iters = Regions_De_Confiance("cauchy",f1,grad_f1,hess_f1,x012,options)
my_afficher_resultats_newton("RDC","f1",x012,xmin,f_min,flag,sol_exacte,nb_iters)


sol_exacte = [1,1]
options = []
x01 = sol_exacte
xmin,f_min,flag,nb_iters = Regions_De_Confiance("cauchy",f2,grad_f2,hess_f2,x01,options)
my_afficher_resultats_newton("RDC","f2",x01,xmin,f_min,flag,sol_exacte,nb_iters)
x021 = [-1.2,1]
xmin,f_min,flag,nb_iters = Regions_De_Confiance("cauchy",f2,grad_f2,hess_f2,x021,options)
my_afficher_resultats_newton("RDC","f2",x021,xmin,f_min,flag,sol_exacte,nb_iters)
x022 = [10,0]
xmin,f_min,flag,nb_iters = Regions_De_Confiance("cauchy",f2,grad_f2,hess_f2,x022,options)
my_afficher_resultats_newton("RDC","f2",x022,xmin,f_min,flag,sol_exacte,nb_iters)
x023 = [0,(1/200)+(1/10^(12))]
xmin,f_min,flag,nb_iters = Regions_De_Confiance("cauchy",f2,grad_f2,hess_f2,x023,options)
my_afficher_resultats_newton("RDC","f2",x023,xmin,f_min,flag,sol_exacte,nb_iters)


#quadratique 4
g4=[0;0]
H4=[-2 0; 0 10]

#quadratique 5
g5=[2;3]
H5=[4 6;6 5]

#quadratique 6
g6=[2;0]
H6=[4 0; 0 -15]


# Nos tests
using LinearAlgebra
using Markdown 

include("Lagrangien_Augmente.jl")

# Affichage les sorties de l'algorithme des Régions de confiance
function my_afficher_resultats_la(algo,fct,cont,point_init,xmin,fxmin,flag,sol_exacte,nbiters)
	println("-------------------------------------------------------------------------")
	printstyled("Résultats de : ",algo, " appliqué à ",fct, " au point initial ", point_init, " avec la contrainte ",cont, ":\n",bold=true,color=:blue)
	println("  * xsol = ",xmin)
	println("  * f(xsol) = ",fxmin)
	println("  * nb_iters = ",nbiters)
	println("  * flag = ",flag)
	println("  * sol_exacte : ", sol_exacte)
end
f1(x) =  2(x[1]+x[2]+x[3]-3)^2 + (x[1]-x[2])^2 + (x[2]-x[3])^2

# le gradient de la fonction f1
grad_f1(x) = [6*x[1]+2*x[2]+4*x[3]-12,2*x[1]+8*x[2]+2*x[3]-12,4*x[1]+2*x[2]+6*x[3]-12]

# la hessienne de la fonction f1
hess_f1(x) = [6 2 4;2 8 2;4 2 6]

sol_exacte = [1,1,1]
options = []

# point initiaux 
xc11 = [1,1,0] # réalisble

contrainte1(x)=x[1]+x[3]-1
grad_contrainte1(x)=[1,0,1]
hess_contrainte1(x)=[0 0 0; 0 0 0; 0 0 0]

# point initial 
xc11 = [0,1,1] # réalisble
xmin,fxmin,flag,iters = Lagrangien_Augmente("cauchy",f1,contrainte1,grad_f1,hess_f1,grad_contrainte1,hess_contrainte1,xc11,options)
my_afficher_resultats_la("cauchy", f1, contrainte1,xc11,xmin,fxmin,flag,sol_exacte,iters)
xmin,fxmin,flag,iters = Lagrangien_Augmente("newton",f1,contrainte1,grad_f1,hess_f1,grad_contrainte1,hess_contrainte1,xc11,options)
my_afficher_resultats_la("newton", f1, contrainte1,xc11,xmin,fxmin,flag,sol_exacte,iters)
xmin,fxmin,flag,iters = Lagrangien_Augmente("gct",f1,contrainte1,grad_f1,hess_f1,grad_contrainte1,hess_contrainte1,xc11,options)
my_afficher_resultats_la("gct", f1, contrainte1,xc11,xmin,fxmin,flag,sol_exacte,iters)

# point initial
xc12= [0.5,1.25,1] # non réalisble
xmin,fxmin,flag,iters = Lagrangien_Augmente("cauchy",f1,contrainte1,grad_f1,hess_f1,grad_contrainte1,hess_contrainte1,xc12,options)
my_afficher_resultats_la("cauchy", f1, contrainte1,xc12,xmin,fxmin,flag,sol_exacte,iters)
xmin,fxmin,flag,iters = Lagrangien_Augmente("newton",f1,contrainte1,grad_f1,hess_f1,grad_contrainte1,hess_contrainte1,xc12,options)
my_afficher_resultats_la("newton", f1, contrainte1,xc12,xmin,fxmin,flag,sol_exacte,iters)
xmin,fxmin,flag,iters = Lagrangien_Augmente("gct",f1,contrainte1,grad_f1,hess_f1,grad_contrainte1,hess_contrainte1,xc12,options)
my_afficher_resultats_la("gct", f1, contrainte1,xc12,xmin,fxmin,flag,sol_exacte,iters)


# Fonction f2
# -----------
f2(x)=100*(x[2]-x[1]^2)^2+(1-x[1])^2

#le gradient de la fonction f2
grad_f2(x)=[-400*(x[1])*(x[2]-x[1]^2)-2*(1-x[1]), 200*(x[2]-x[1]^2)]

#la hessienne de la fonction f2
hess_f2(x)=[-400*((x[2]-x[1]^2)-2*x[1]^2)+2 -400*x[1]; -400*x[1] 200]

sol_exacte = [1,1]
options = []

contrainte2(x)=x[1]^2+x[2]^2-1.5
grad_contrainte2(x)=[2*x[1],2*x[2]]
hess_contrainte2(x)=2*[1 0; 0 1]


# Fonction f2
# -----------
f2(x)=100*(x[2]-x[1]^2)^2+(1-x[1])^2

#le gradient de la fonction f2
grad_f2(x)=[-400*(x[1])*(x[2]-x[1]^2)-2*(1-x[1]), 200*(x[2]-x[1]^2)]

#la hessienne de la fonction f2
hess_f2(x)=[-400*((x[2]-x[1]^2)-2*x[1]^2)+2 -400*x[1]; -400*x[1] 200]

sol_exacte = "Undefined"
options = []

contrainte2(x)=x[1]^2+x[2]^2-1.5
grad_contrainte2(x)=[2*x[1],2*x[2]]
hess_contrainte2(x)=2*[1 0; 0 1]

#point initial non realisable
xc21=[1,0]
xmin,fxmin,flag,iters = Lagrangien_Augmente("cauchy",f2,contrainte2,grad_f2,hess_f2,grad_contrainte2,hess_contrainte2,xc21,options)
my_afficher_resultats_la("cauchy", f2, contrainte1,xc21,xmin,fxmin,flag,sol_exacte,iters)
xmin,fxmin,flag,iters = Lagrangien_Augmente("newton",f2,contrainte2,grad_f2,hess_f2,grad_contrainte2,hess_contrainte2,xc21,options)
my_afficher_resultats_la("newton", f2, contrainte1,xc21,xmin,fxmin,flag,sol_exacte,iters)
xmin,fxmin,flag,iters = Lagrangien_Augmente("gct",f2,contrainte2,grad_f2,hess_f2,grad_contrainte2,hess_contrainte2,xc21,options)
my_afficher_resultats_la("gct", f2, contrainte1,xc21,xmin,fxmin,flag,sol_exacte,iters)

#point initial
xc22=[sqrt(3)/2,sqrt(3)/2]
xmin,fxmin,flag,iters = Lagrangien_Augmente("cauchy",f2,contrainte2,grad_f2,hess_f2,grad_contrainte2,hess_contrainte2,xc22,options)
my_afficher_resultats_la("cauchy", f2, contrainte1,xc22,xmin,fxmin,flag,sol_exacte,iters)
xmin,fxmin,flag,iters = Lagrangien_Augmente("newton",f2,contrainte2,grad_f2,hess_f2,grad_contrainte2,hess_contrainte2,xc22,options)
my_afficher_resultats_la("newton", f2, contrainte1,xc22,xmin,fxmin,flag,sol_exacte,iters)
xmin,fxmin,flag,iters = Lagrangien_Augmente("gct",f2,contrainte2,grad_f2,hess_f2,grad_contrainte2,hess_contrainte2,xc22,options)
my_afficher_resultats_la("gct", f2, contrainte1,xc22,xmin,fxmin,flag,sol_exacte,iters)