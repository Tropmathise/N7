// Time-stamp: <24 fév 2010 09:39 queinnec@enseeiht.fr>

public enum EtatFourchette {
    Table,
    AssietteGauche,
    AssietteDroite;
}	
