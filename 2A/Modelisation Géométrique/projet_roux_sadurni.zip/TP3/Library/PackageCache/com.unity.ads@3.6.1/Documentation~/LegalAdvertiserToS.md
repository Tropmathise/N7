<script type="text/javascript">

window.location = "https://unity3d.com/legal/ads-advertisers-terms-of-service"

</script>
